<?php
    $form_errors = array();
    if(isset($_POST['submit'])){

        $required_fields = array('flight_name', 'flight_no');
        //check empty fields and merge the error msg
        $form_errors = array_merge($form_errors, check_empty_fields($required_fields));
         if(empty($form_errors)) {
            // if empty, process data
    try{
        $sqlInsert =  "INSERT INTO flights_info (flight_name, flight_no, s_airport_id, d_airport_id, type, economy, business, firstclass, sl) ";
        $sqlInsert .= "VALUES (:tname, :tno, :sid, :did, :type, :3ac, :2ac, :1ac, :sl)";

        $statement = $db->prepare($sqlInsert);
        $statement->execute(array(':tname' => $_POST['flight_name'], ':tno' => $_POST['flight_no'], ':sid' => $_POST['s_airport_id'], ':did' => $_POST['d_airport_id'], ':type' => $_POST['type'], ':3ac' => $_POST['ac3'], ':2ac' => $_POST['ac2'], ':1ac' => $_POST['ac1'], ':sl' => $_POST['sl']));
                     if($statement -> rowCount() == 1){
                         try{
                    $sqlInsert =  "INSERT INTO flightseat (flight_no, economy, business, firstclass, sl) ";
                    $sqlInsert .= "VALUES (:tno, :3ac, :2ac, :1ac, :sl )";

                    $statement = $db->prepare($sqlInsert);
                    $statement->execute(array(':tno' => $_POST['flight_no'], ':3ac' => $_POST['ac3'], ':2ac' => $_POST['ac2'], ':1ac' => $_POST['ac1'], ':sl' => $_POST['sl']));
                                if($statement -> rowCount() == 1){
                                    $result = "<script type=\"text/javascript\"> 
                                    swal({   
                                        title: \"Congrats !\", 
                                        type:'success',  
                                        text: \"Flight Added.\",
                                        confirmButtonText: \"Thank you!\",    
                                        
                                        });
                                        </script>";
                            //$result = flashMessage("Registration succesful" ,"pass");
                            }
                        }catch (PDOException $ex){
                                $result = flashMessage("Error occured : " . $ex->getMessage() );
                        }
                }
            }catch (PDOException $ex){
                    $result = flashMessage("Error occured : " . $ex->getMessage() );
            }
    }
    else{
        if(count($form_errors) == 1){
             $result  = flashMessage("There was one error in the form <br/>");
        }
        else{
        $result  = flashMessage("There were " . count($form_errors). " errors in the form <br />");
        }
    }
}

?>