<?php
ob_start();
require_once("resource/Database.php"); //db connection ?>
<?php require_once("resource/utilities.php"); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
<?php $page_title = "ARS"; ?>
<?php require_once("patches/header.php"); ?>
 <?php if(!isset($_SESSION['username'])): ?>
<div class="container">
    <div class="flag">
        <h1>A R S</h1>
    <p> You are currently not sign in <br/>
    <a href="login.php">Login here
    </p>
    </div>
</div>

<?php else: ?>
<div>
        <?php if(isset($result)) echo $result; ?>
        <?php if(!empty($form_errors)) echo show_errors($form_errors); ?>
</div>

<div class="row">
<div class="col-md-2"></div>
<div class="col-md-6 pull-center">
    <div class="jumbotron">
        <center><h2>Enter Flight no to search</h2></center>  
    </div>
</div>
</div>
        <div class="col-md-9">
        
        </div>
        <br/>
        <form action="" method="post">
            <br/>
            <div class="row">
                <div class="col-md-6">
                    <div class="col-xs-6 pull-right">
                        <label for="ex1">Flight no</label>
                        <input type="text" class="form-control" name="flight_no" />
                    </div>
                </div>
            </div>
            <br/>
            <br/>
            <div class="col-md-9">
                <center>
                    <input type="submit" name="searchtno" class="btn btn-info" value="Search Flight"> </center>
            </div>
    </div>
    </form>
    </div>
    <br/>
    <br/>

    <?php
    $form_errors = array();
    if(isset($_POST['searchtno'])){

        $required_fields = array('flight_no');
        //check empty fields and merge the error msg
        $form_errors = array_merge($form_errors, check_empty_fields($required_fields));
         if(empty($form_errors)) {
            // if empty, process data
    try{
        $sqlInsert =  "SELECT * FROM flights_info WHERE flight_no = :tno";
        $statement = $db->prepare($sqlInsert);
        $statement->execute(array(':tno' => $_POST['flight_no']));

                while($row = $statement->fetch()){
                $tr_no = $row['flight_no'];
                $tr_nm = $row['flight_name'];
                $tr_tp = $row['type'];
                $tr_src = $row['s_airport_id'];
                $tr_dest = $row['d_airport_id'];
                $tr3_ac = $row['economy'];
                $tr2_ac = $row['business'];
                $tr1_ac = $row['firstclass'];

                $sst_nm = getstname($db,$tr_src);
                $dst_nm = getstname($db,$tr_dest);     
                  
                  echo "<div class=\"row\">
                  <div class=\"col-md-6\">
                    <table class=\"table\">
                        <thead>
                            <tr>
                            <th>#</th>
                            <th>Flight no</th>
                            <th>Flight name</th>
                            <th>Source</th>
                            <th>Destination</th>
                            <th>Economy</th>
                            <th>Business</th>
                            <th>First Class</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                            <th scope=\"row\">1</th>
                            <td>$tr_no</td>
                            <td>$tr_nm</td>
                            <td>$sst_nm</td>
                            <td>$dst_nm</td>
                            <td>$tr3_ac</td>
                            <td>$tr2_ac</td>
                            <td>$tr1_ac</td>
                            </tr>
                        </tbody>
                    </table>
                  ";
                //$result = flashMessage("Registration succesful" ,"pass");
                }
            }catch (PDOException $ex){
                    $result = flashMessage("Error occured : " . $ex->getMessage() );
            }
    }
    else{
        if(count($form_errors) == 1){
             $result  = flashMessage("There was one error in the form <br/>");
        }
        else{
        $result  = flashMessage("There were " . count($form_errors). " errors in the form <br />");
        }
    }
}

?>

<?php endif ?>

<?php require_once("patches/footer.php"); ?>