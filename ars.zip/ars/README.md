Instructions to run the prototype :


1) Install the Wamp/Xamp server.
2) Start all the service on the respective server you have downloaded.
3) Open localhost in any browser and then click on the PHPMYADMIN.
4) Login to the PHPMYADMIN, create a Database named "ars" in it.
5) Download the project source code and store it on your "wamp/www/" folder or "xamp/htdocs/" folder.
6) In the PHPMYADMIN after you have created a database named "ars" click import sql code from the downloaded folder which will be named ars.sql and click ok.
7) After importing the sql file open "localhost/ars/ui/index.html" which is the main page of the Website.
8) There is login page for admin as well as user.
9) If you are not signed up, please first sign up on the website and then login.
10) After login only you can book,search , cancel and check the ticket
11) There is a login page for admin too for adding the flights,flights routes etc.
12) To add flights, flights routes login as admin to adminlogin page on the main page. The password is "adminlogin" .
13) The full functionality can be explored by searching and booking the ticket.