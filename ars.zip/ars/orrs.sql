-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2019 at 10:13 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `orrs`
--

-- --------------------------------------------------------

--
-- Table structure for table `flightseat`
--

CREATE TABLE `flightseat` (
  `flight_no` int(4) NOT NULL,
  `economy` int(4) DEFAULT NULL,
  `business` int(4) DEFAULT NULL,
  `firstclass` int(4) DEFAULT NULL,
  `sl` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flightseat`
--

INSERT INTO `flightseat` (`flight_no`, `economy`, `business`, `firstclass`, `sl`) VALUES
(1155, 50, 50, 50, NULL),
(1239, 50, 50, 50, NULL),
(2203, 50, 42, 50, 50),
(2250, 50, 50, 50, 50),
(3355, 50, 50, 50, NULL),
(3500, 50, 50, 50, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `flights_info`
--

CREATE TABLE `flights_info` (
  `flight_no` int(4) NOT NULL,
  `flight_name` varchar(30) DEFAULT NULL,
  `s_airport_id` int(4) NOT NULL,
  `d_airport_id` int(4) NOT NULL,
  `sl` int(4) DEFAULT NULL,
  `economy` int(4) DEFAULT NULL,
  `business` int(4) DEFAULT NULL,
  `firstclass` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flights_info`
--

INSERT INTO `flights_info` (`flight_no`, `flight_name`, `s_airport_id`, `d_airport_id`, `sl`, `economy`, `business`, `firstclass`) VALUES
(1155, 'SPICEJET', 5001, 5004, NULL, 50, 50, 50),
(1239, 'INDIGO-A50', 5001, 5003, NULL, 50, 50, 50),
(2203, 'INDIGO', 5001, 5005, 50, 50, 42, 50),
(2250, 'GO AIR', 5005, 5001, 50, 50, 50, 50),
(3355, 'SPICEJET-A18', 5003, 5001, NULL, 50, 50, 50),
(3500, 'AIR INDIA', 5003, 5005, NULL, 50, 50, 50);

-- --------------------------------------------------------

--
-- Table structure for table `flight_route`
--

CREATE TABLE `flight_route` (
  `airport_id` int(4) NOT NULL,
  `airport_name` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flight_route`
--

INSERT INTO `flight_route` (`airport_id`, `airport_name`) VALUES
(5001, 'DELHI'),
(5003, 'BANGLORE'),
(5004, 'PATNA'),
(5005, 'MADRAS');

-- --------------------------------------------------------

--
-- Table structure for table `flight_schedule`
--

CREATE TABLE `flight_schedule` (
  `flight_no` int(4) NOT NULL,
  `airport_id` int(4) NOT NULL,
  `arr_time` varchar(10) DEFAULT NULL,
  `dep_time` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flight_schedule`
--

INSERT INTO `flight_schedule` (`flight_no`, `airport_id`, `arr_time`, `dep_time`) VALUES
(3500, 5003, '13:00:00', '05:00:00'),
(3355, 5003, '08:00:00', '10:00:00'),
(2250, 5005, '06:00:00', '08:15:00'),
(2203, 5001, '3:00:00', '7:00:00'),
(1239, 5001, '02:00:00', '03:15:00'),
(1155, 5001, '16:00:00', '20:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `ticketid` int(2) NOT NULL,
  `flight_no` int(4) NOT NULL,
  `username` varchar(25) NOT NULL,
  `Name` tinytext NOT NULL,
  `age` int(11) NOT NULL,
  `seat` int(5) NOT NULL,
  `source` varchar(25) NOT NULL,
  `destination` varchar(25) NOT NULL,
  `type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`ticketid`, `flight_no`, `username`, `Name`, `age`, `seat`, `source`, `destination`, `type`) VALUES
(57, 1122, 'airbus', 'aribus', 22, 2, 'delhi', 'aluva', 'Business'),
(59, 2203, 'airbus', 'airbuss1', 22, 2, 'Delhi', 'Madras', 'business');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(6) UNSIGNED NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `datejoined` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `activated` enum('0','1') NOT NULL DEFAULT '0',
  `avatar` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `datejoined`, `activated`, `avatar`) VALUES
(1, 'reserve', '3ae9d8799d1bb5e201e5704293bb54ef', 'er@gf', '2016-10-14 19:23:52', '0', 'link.png'),
(2, 'admin', '8f96e4f5fcff936298f13a4b8db8a242', 'admin@orrs', '2016-10-21 09:15:24', '0', NULL),
(3, 'student', 'cd73502828457d15655bbd7a63fb0bc8', 'e@werw', '2016-10-30 20:33:20', '0', NULL),
(4, 'airbus', 'aa1a0071d3bbaad3075a14cca8b42119', 'airbus@airbus.com', '2019-12-08 04:49:09', '0', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `flightseat`
--
ALTER TABLE `flightseat`
  ADD KEY `train_no` (`flight_no`),
  ADD KEY `thirdtier` (`economy`),
  ADD KEY `secondtier` (`business`),
  ADD KEY `firsttier` (`firstclass`),
  ADD KEY `sl` (`sl`);

--
-- Indexes for table `flights_info`
--
ALTER TABLE `flights_info`
  ADD PRIMARY KEY (`flight_no`),
  ADD KEY `s_station_id` (`s_airport_id`),
  ADD KEY `d_station_id` (`d_airport_id`),
  ADD KEY `sl` (`sl`),
  ADD KEY `firsttier` (`firstclass`),
  ADD KEY `secondtier` (`business`),
  ADD KEY `thirdtier` (`economy`);

--
-- Indexes for table `flight_route`
--
ALTER TABLE `flight_route`
  ADD PRIMARY KEY (`airport_id`);

--
-- Indexes for table `flight_schedule`
--
ALTER TABLE `flight_schedule`
  ADD KEY `station_id` (`airport_id`),
  ADD KEY `train_no` (`flight_no`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`ticketid`),
  ADD KEY `username` (`username`),
  ADD KEY `train_no` (`flight_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ticket`
--
ALTER TABLE `ticket`
  MODIFY `ticketid` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `flightseat`
--
ALTER TABLE `flightseat`
  ADD CONSTRAINT `flightseat_ibfk_1` FOREIGN KEY (`flight_no`) REFERENCES `flights_info` (`flight_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `flightseat_ibfk_4` FOREIGN KEY (`economy`) REFERENCES `flights_info` (`economy`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `flightseat_ibfk_5` FOREIGN KEY (`business`) REFERENCES `flights_info` (`business`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `flightseat_ibfk_6` FOREIGN KEY (`firstclass`) REFERENCES `flights_info` (`firstclass`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `flightseat_ibfk_7` FOREIGN KEY (`sl`) REFERENCES `flights_info` (`sl`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `flights_info`
--
ALTER TABLE `flights_info`
  ADD CONSTRAINT `flights_info_ibfk_3` FOREIGN KEY (`s_airport_id`) REFERENCES `flight_route` (`airport_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `flights_info_ibfk_4` FOREIGN KEY (`d_airport_id`) REFERENCES `flight_route` (`airport_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `flight_schedule`
--
ALTER TABLE `flight_schedule`
  ADD CONSTRAINT `flight_schedule_ibfk_5` FOREIGN KEY (`airport_id`) REFERENCES `flight_route` (`airport_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `flight_schedule_ibfk_6` FOREIGN KEY (`flight_no`) REFERENCES `flights_info` (`flight_no`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ticket`
--
ALTER TABLE `ticket`
  ADD CONSTRAINT `ticket_ibfk_1` FOREIGN KEY (`username`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ticket_ibfk_2` FOREIGN KEY (`flight_no`) REFERENCES `flights_info` (`flight_no`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
